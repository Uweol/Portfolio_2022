// 상단메뉴
let menuClick = true;
let list = $('#nav .left li')
list.find('.popdown').hide();

list.hover(function(){
    $(this).find('.popdown').show();
},function(){
    $(this).find('.popdown').hide();
})

// 상단메뉴 모바일
let menuClick1 = true;
let list_m = $('#nav .left li')
let list_s = $('.category-list .category .m_category>li')
let list_i = $('#nav .left li .m_img')
let num = 0;

list_i.hide();
list_m.find('.popdown').hide();
list_s.find('.list').hide();

list_m.hover(function(){
    $(this).find('.popdown').show();
},function(){
    $(this).find('.popdown').hide();
})

list_s.hover(function(){
    list_i.hide();
    $(this).find('.list').show();
    $(this).find('.list').css('top', -num*20)
},function(){
    $(this).find('.list').hide();
    list_i.show();
})


// 배너 슬라이드
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,

    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    centeredSlides: true,
    autoplay: {
      delay: 2000,
         disableOnInteraction: false,
      pauseOnMouseEnter : true,

     },
      
  });

  //new, best
  let new_m = $('#new .new_menu');
  let new_s = $("#new .swiper")
  let m_on = new_m.find('li');
  new_s.slice(1,7).hide();
  
  m_on.click(function(e){
    e.preventDefault();
    var idx = $("#new .new_menu>li").index(this);
    m_on.removeClass('on');
    $(this).addClass('on');
    new_s.hide();
    new_s.fadeOut("fast");
    new_s.eq(idx).fadeIn("fast"); 
    
  })