// 상단메뉴
let menuClick = true;
let list = $('#nav .left li')
list.find('.popdown').hide();

list.hover(function(){
    $(this).find('.popdown').show();
},function(){
    $(this).find('.popdown').hide();
})

// 배너 슬라이드
let 